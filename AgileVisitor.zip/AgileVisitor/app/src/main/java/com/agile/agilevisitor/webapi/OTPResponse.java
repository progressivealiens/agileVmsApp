package com.agile.agilevisitor.webapi;

public class OTPResponse {
    /**
     * Status : Success
     * Details : 8ac0b42e-ddd3-44bd-896f-e66c8f25cbd2
     */

    private String Status;
    private String Details;

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String Details) {
        this.Details = Details;
    }
}
