package com.agile.agilevisitor.views.activity.user_panel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.agile.agilevisitor.R;

public class VisitorHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_history);
    }
}
